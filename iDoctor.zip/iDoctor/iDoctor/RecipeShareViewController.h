//
//  RecipeShareViewController.h
//  iDoctor
//
//  Created by Stanimir Nikolov on 1/18/14.
//  Copyright (c) 2014 Stanimir Nikolov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecipeShareViewController : UIViewController

@property (nonatomic, strong) NSArray* medicines;

@end
