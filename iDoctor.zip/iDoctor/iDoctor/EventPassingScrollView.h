//
//  EventPassingScrollView.h
//  iDoctor
//
//  Created by Stanimir Nikolov on 1/19/14.
//  Copyright (c) 2014 Stanimir Nikolov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EventPassingScrollView : UIScrollView

@end
