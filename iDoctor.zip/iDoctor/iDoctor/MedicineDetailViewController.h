//
//  MedicineDetailViewController.h
//  iDoctor
//
//  Created by Stanimir Nikolov on 12/31/13.
//  Copyright (c) 2013 Stanimir Nikolov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MedicineDetailViewController : UIViewController

@property (nonatomic, strong) NSString* medicineName;
@property (nonatomic, strong) NSString* medicineUrl;

@end
